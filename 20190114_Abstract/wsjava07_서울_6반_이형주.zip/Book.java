package Book;
public class Book extends Product {


public Book(int isbn, int price, int desc, String title, String author, String publisher) {
	super(isbn,price,desc,title,author,publisher);
}


}
