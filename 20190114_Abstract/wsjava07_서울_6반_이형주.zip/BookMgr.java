package Book;

public class BookMgr{

	private Product[] product = new Product[100];
	
	
	private int index = 0;
	
	public void add(Product p)
	{
		product[index] = p;
		index++;
	} //데이터 입력기능

	public Product[] search() {
		
		return product;
	} //데이터 전체 검색기능
	
	public Product[] search(int num) {
		Product pr[] = new Product[100]; // 객체의 주소를 저장할 100칸 생성, 각 칸에는 null
		
		int ind = 0;
		for(int i=0; i<index; i++)
		{
			if(product[i].getIsbn()==num)
			{
				pr[ind] = product[i];
				ind++;
			}
		}
		return pr;
	} //isbn으로 검색하는 기능
	
	public Product[] search(String name)
	{
		Product pr[] = new Product[100]; // 객체의 주소를 저장할 100칸 생성, 각 칸에는 null
		
		int ind = 0;
		for(int i=0; i<index; i++)
		{
			if(product[i].getTitle().contains(name))
			{			
				pr[ind] = product[i];
				ind++;
			}
		}
		return pr;
	} //Title로 정보를 검색하는 기능.
	
	
	public Product[] searchBook()
	{
		Product pr[] = new Product[100]; // 객체의 주소를 저장할 100칸 생성, 각 칸에는 null
		
		int ind = 0;
		for(int i=0; i<index; i++)
		{
			if(product[i] instanceof Book)
			{			
				pr[ind] = product[i];
				ind++;
			}
		}
		return pr;
	} //Book만 검색하는 기능
	

	public Product[] searchMagazine()
	{
		Product pr[] = new Product[100]; // 객체의 주소를 저장할 100칸 생성, 각 칸에는 null
		
		int ind = 0;
		for(int i=0; i<index; i++)
		{
			if(product[i] instanceof Magazine)
			{			
				pr[ind] = product[i];
				ind++;
			}
		}
		return pr;
	} //magazine만 검색하는 기능
	
	
	
	public Product[] searchPublisher(String publisher)
	{
		Product pr[] = new Product[100]; // 객체의 주소를 저장할 100칸 생성, 각 칸에는 null
		
		int ind = 0;
		for(int i=0; i<index; i++)
		{
			if(product[i].getPublisher().equals(publisher))
			{			
				pr[ind] = product[i];
				ind++;
			}
		}
		return pr;
	} //출판사로 정보를 검색하는 기능.
	
	
	public Product[] searchPrice(int price)
	{
		Product pr[] = new Product[100]; // 객체의 주소를 저장할 100칸 생성, 각 칸에는 null
		
		int ind = 0;
		for(int i=0; i<index; i++)
		{
			if(product[i].getPrice()<=price)
			{			
				pr[ind] = product[i];
				ind++;
			}
		}
		return pr;
	} //가격으로 검색기능(주어진 파라메터보다 가격 낮은 도서)
	

	public Product[] searchYear(int year) {
		Product pr[] = searchMagazine();
		
		int ind = 0;
		
		for(int i=0; i<index; i++)
		{
			Product a =pr[i];
			Magazine b	=(Magazine)a;

			if(b.getYear()==year)
			{
				pr[ind] = b;
				ind++;
			}
		}
		return pr;
	}
	
	
	public int getSum()
	{
		int count=0;
		for(int i=0; i<index; i++)
			count+=product[i].getPrice();
		
		return count;
	} //도서의 총 합계
	
	public int getAvg()
	{
		int count=0;
		for(int i=0; i<index; i++)
			count+=product[i].getPrice();
		
		return count/index;
	} //도서의 평균
	
	public int getSize()
	{
		return index;
	}
}
